package dev.warpscout.app

import android.app.Activity
import dev.warpscout.core.model.WarpConfig
import dev.warpscout.core.tune.TunnelVerifier

/**
 * Мост к собственному туннелю. В сборке `scout` реализации нет (возвращается
 * [UnsupportedTunnelController]) — там конфигурация передаётся в AmneziaVPN.
 * В сборке `tunnel` работает [VpnTunnelController] поверх VpnService.
 */
interface TunnelController {
    val supported: Boolean
    val isUp: Boolean
    val status: String

    /** true — если разрешение на VPN уже выдано и туннель можно поднимать. */
    fun ensurePermission(activity: Activity): Boolean

    fun start(config: WarpConfig): Boolean
    fun stop()

    /** Верификация доступности ресурсов из-под туннеля; null — если туннеля нет. */
    fun verifier(): TunnelVerifier? = null
}

class UnsupportedTunnelController : TunnelController {
    override val supported: Boolean get() = false
    override val isUp: Boolean get() = false
    override val status: String get() = "Туннеля в этой сборке нет"
    override fun ensurePermission(activity: Activity): Boolean = false
    override fun start(config: WarpConfig): Boolean = false
    override fun stop() {}
}
